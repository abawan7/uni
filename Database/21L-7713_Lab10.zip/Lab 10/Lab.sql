
-- SQL Database Script

-- Create Database
CREATE DATABASE Lab10Exercise2;
GO

USE Lab10Exercise2;
GO

-- Create Items Table
CREATE TABLE Items (
    ItemID INT PRIMARY KEY IDENTITY(1,1),
    ItemName NVARCHAR(100),
    Quantity INT,
    Description NVARCHAR(255)
);
GO

-- Create SearchItems Stored Procedure
CREATE PROCEDURE SearchItems
    @SearchTerm NVARCHAR(100)
AS
BEGIN
    SELECT * FROM Items WHERE ItemName LIKE '%' + @SearchTerm + '%';
END;
GO
