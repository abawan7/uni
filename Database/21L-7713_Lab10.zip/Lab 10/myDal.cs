
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public class myDal
{
    private SqlConnection con;

    public myDal()
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["YourConnectionString"].ToString());
    }

    public DataTable SearchItems(string searchTerm)
    {
        SqlCommand cmd = new SqlCommand("SearchItems", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@SearchTerm", searchTerm);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }
}
