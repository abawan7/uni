
using System;
using System.Data;

public partial class PostLab : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        myDal dal = new myDal();
        string searchTerm = txtSearch.Text;
        DataTable dt = dal.PostLabSearch(searchTerm); // Assume a different method for post-lab search
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
}
